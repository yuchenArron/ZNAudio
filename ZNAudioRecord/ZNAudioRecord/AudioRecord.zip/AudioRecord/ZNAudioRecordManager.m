
//
//  ZNAudioRecordManager.m
//  ZNAudioRecord
//
//  Created by mac on 2017/8/29.
//  Copyright © 2017年 Netposa. All rights reserved.
//

#import "ZNAudioRecordManager.h"
#import "ZZAudioRecorderUtil.h"

#define PerRecordFileLimitCount  2 * 60

@interface ZNAudioRecordManager()<SpectrumViewDelegate>

@property (nonatomic, strong) NSTimer *totalTimer;
@property (nonatomic, assign) NSInteger totalTimeCount;

@end

@implementation ZNAudioRecordManager

- (NSTimer *)totalTimer{
    if (!_totalTimer) {
        _totalTimeCount = 0;
        _totalTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(recordCountTimer:) userInfo:nil repeats:YES];
        [_totalTimer fire];
    }
    return _totalTimer;
}

- (SpectrumView *)recordViewWithFrame:(CGRect)frame{
    SpectrumView *recordView = [[SpectrumView alloc]initWithFrame:frame];
    recordView.delegate  = self;
    
    return recordView;
}

#pragma mark - timer
- (void)recordCountTimer:(NSTimer*)timer{
    
    if (self.totalTimeCount % PerRecordFileLimitCount == 0) {
        
    }
    
    
    self.totalTimeCount ++;
}

#pragma mark - SpectrumViewDelegate

- (void)viewDelegateStartRecord{
    
}

- (void)viewDelegatePauseRecord{

}

- (void)viewDelegateCancelRecord{

}

- (void)viewDelegateResumeRecord{

}

- (void)viewDelegateFinishRecord{

    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    
    UIViewController *viewController = [self getCurrentVC];
    [viewController presentViewController:alertController animated:YES completion:nil];
    
}

//获取当前屏幕显示的viewcontroller   (这里面获取的相当于rootViewController)
- (UIViewController *)getCurrentVC
{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows)
        {
            if (tmpWin.windowLevel == UIWindowLevelNormal)
            {
                window = tmpWin;
                break;
            }
        }
    }
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else
        result = window.rootViewController;
    
    return result;
}


@end
